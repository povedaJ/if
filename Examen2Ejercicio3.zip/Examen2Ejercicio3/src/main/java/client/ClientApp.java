package client;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;

public class ClientApp {

    Socket clienteSocket;

    public ClientApp(String server, int port) {
        try {
            // Crear socket y streams de salida
            this.clienteSocket = new Socket(server, port);
            ObjectOutputStream out = new ObjectOutputStream(clienteSocket.getOutputStream());

            // Recibir palabras del cliente
            BufferedReader lineReader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Ingresa la primera palabra: ");
            String word1 = lineReader.readLine();

            System.out.print("Ingresa la segunda palabra: ");
            String word2 = lineReader.readLine();

            // Enviar palabras al servidor
            List<String> words = Arrays.asList(word1, word2);
            out.writeObject(words);

            ObjectInputStream in = new ObjectInputStream(clienteSocket.getInputStream());
            String response = (String) in.readObject();
            if (response.equals("OK")) {
                System.out.println("Las palabras " + word1 + " y " + word2 + " si son un palíndromo");
            } else if (response.equals("NO")) {
                System.out.println("Las palabras " + word1 + " y " + word2 + " no son un palíndromo");
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                clienteSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
