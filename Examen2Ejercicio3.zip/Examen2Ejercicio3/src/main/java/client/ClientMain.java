package client;

public class ClientMain {
    public static void main(String[] args) {
        ClientApp clientApp = new ClientApp("127.0.0.1", 50001);
    }
}
