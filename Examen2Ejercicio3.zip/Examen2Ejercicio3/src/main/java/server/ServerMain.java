package server;

public class ServerMain {
    public static void main(String[] args) {
        ServerApp serverApp = new ServerApp(50001);
    }
}
