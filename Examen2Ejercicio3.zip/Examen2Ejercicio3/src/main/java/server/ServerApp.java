package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class ServerApp {

    private ServerSocket serverSocket;

    public ServerApp (int port) {
        try {
            this.serverSocket = new ServerSocket(port);
            while (true) {
                Socket socket = serverSocket.accept();
                // Crear streams de entrada y salida
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                // Leer palabras
                List<String> words = (List<String>) in.readObject();
                if (words.get(0).length() != words.get(1).length()) {
                    out.writeObject("NO");
                    continue;
                }
                boolean isPalindromo = true;
                for (int i = 0; i < words.get(0).length(); i++) {
                    if (words.get(0).charAt(i) != words.get(1).charAt(words.get(0).length() - 1 - i)) {
                        isPalindromo = false;
                        break;
                    }
                }
                if (isPalindromo) {
                    out.writeObject("OK");
                } else {
                    out.writeObject("NO");
                }
            }
        } catch  (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
