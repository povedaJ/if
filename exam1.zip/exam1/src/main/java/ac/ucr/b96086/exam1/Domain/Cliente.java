/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b96086.exam1.Domain;

import java.time.LocalDate;

/**
 *
 * @author Equipo
 */
public class Cliente {
    private String name;
    private String iD;
    private String email;
    private double discount;
    private double accumulated; 
    private String  costomerType;
    private LocalDate registrationDate;

    public Cliente(String name, String iD, String email, String costomerType, LocalDate registrationDate) {
        this.name = name;
        this.iD = iD;
        this.email = email;
        this.costomerType = costomerType;
        this.registrationDate = registrationDate;
        this.discount=0; 
    }

    public double getAccumulated() {
        return accumulated;
    }

    public void setAccumulated(double accumulated) {
        this.accumulated = this.accumulated +accumulated;
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(long discount) {
        this.discount = discount;
    }

    public String getCostomerType() {
        return costomerType;
    }

    public void setCostomerType(String costomerType) {
        this.costomerType = costomerType;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    @Override
    public String toString() {
        return "Cliente : "+name+" Tipo "+ costomerType;
    }
    
    
    

    
}//class
