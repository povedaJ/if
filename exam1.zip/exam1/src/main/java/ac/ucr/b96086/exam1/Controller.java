/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ac.ucr.b96086.exam1;

import ac.ucr.b96086.exam1.Domain.Cliente;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Equipo
 */
public class Controller {

    ArrayList<Cliente> listClientes = new ArrayList<>();
    //  private double price;
    private double discount;

    public Controller(ArrayList<Cliente> clientes) {
        this.listClientes = clientes;

    }// Controller


    public double calculateDiscount(double price, Cliente cliente) {

        if (cliente.getCostomerType().equals("Esmeralda")) {
            // pricediscount  price

            discount = price * 0.1;

            return (price - discount);
        } else {
            if (cliente.getCostomerType().equals("Diamante") && price > 30000) {

                discount = price * 0.08;
                return (price - discount);
            } else {
                if (cliente.getCostomerType().equals("Oro") && price > 100000) {

                    discount = price * 0.07;
                    return (price - discount);
                } else {
                    if (cliente.getCostomerType().equals("Plata") && price >150000) {

                        discount = price * 0.05;
                        return (price - discount);
                    }
                }

                return price;// es decir es bronce y no recibe descuento 

            }}
          
    
    }// debe retornar el monto del descuento 
            //  public void confirmBuy(){} // Dado un precio final, debe acumular el monto pagado. llamo a calculateDisconunt y debo editar el monto acumulado 
    

    public void accumulated(double price, Cliente cliente) {
         
        cliente.setAccumulated(calculateDiscount(price, cliente));
    }
   



}// class
