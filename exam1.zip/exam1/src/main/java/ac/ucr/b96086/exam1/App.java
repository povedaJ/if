package ac.ucr.b96086.exam1;

import ac.ucr.b96086.exam1.Domain.Cliente;
import java.time.LocalDate;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Equipo
 */
public class App {

    public static void main(String arg[]) {
ArrayList<Cliente> clientes  = new ArrayList<>();
        Controller control = new Controller(clientes);
        Cliente cBronce = new Cliente("Randall", "305150861", "Randall@gmail.com", "Bronce", LocalDate.now());
        Cliente cPlata = new Cliente("Viviana", "305150861", "Viviana@gmail.com", "Plata", LocalDate.now());
        Cliente cOro = new Cliente("Gerson", "305150861", "Gerson@gmail.com", "Oro", LocalDate.now());
        Cliente cDiamante = new Cliente("Annet", "305150861", "Annet@gmail.com", "Diamante", LocalDate.now());
        Cliente cEsmeralda = new Cliente("Leo Camacho", "305150861", "LEO@gmail.com", "Esmeralda", LocalDate.now());
      
        
        System.out.println(cBronce.toString());
       System.out.println("price: 200 000 "+ " Con descuento");
      System.out.println( control.calculateDiscount(200000, cBronce));
      control.accumulated(200000, cBronce);
      System.out.println( "ACUMULADO "+cBronce.getAccumulated());

        System.out.println(cPlata.toString());
        System.out.println("price: 200 000 "+ " Con descuento");
        System.out.println( control.calculateDiscount(200000, cPlata));
        control.accumulated(200000, cPlata);
        System.out.println("ACUMULADO "+ cPlata.getAccumulated());

        System.out.println(cOro.toString());
        System.out.println("price: 200 000 "+ " Con descuento");
        System.out.println( control.calculateDiscount(200000, cOro));
        control.accumulated(200000, cOro);
        System.out.println( "ACUMULADO "+ cOro.getAccumulated());



        System.out.println(cDiamante.toString());
        System.out.println("price: 200 000 "+ " Con descuento");
        System.out.println( control.calculateDiscount(200000, cDiamante));
        control.accumulated(200000, cDiamante);
        System.out.println("ACUMULADO "+ cDiamante.getAccumulated());


        System.out.println(cEsmeralda.toString());
        System.out.println("price: 200 000 "+ " Con descuento");
        System.out.println( control.calculateDiscount(200000, cEsmeralda));
        control.accumulated(200000, cEsmeralda);
        System.out.println( "ACUMULADO "+cEsmeralda.getAccumulated());


        // prueba de esmeraldsa para ver le acumulado
        System.out.println("Para verificar el acumulado ");
        System.out.println(cEsmeralda.toString());
        System.out.println("price: 200 000 "+ " Con descuento");
        System.out.println( control.calculateDiscount(200000, cEsmeralda));
        control.accumulated(200000, cEsmeralda);
        System.out.println( "ACUMULADO "+cEsmeralda.getAccumulated());

        

        //control.
    }// main 
}// class
