package ac.ucr.b96086.practicaExam2.concurrency.volatilized;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VolatileDemo {
    public static void main(String[] args) throws InterruptedException {
        executeDemo();
    }

    public static void executeDemo() throws InterruptedException {
        System.out.println("Principal:" + Thread.currentThread().getName());
        ExecutorService service = Executors.newCachedThreadPool();
        CountDownLatch countDownLatch = new CountDownLatch(2);
        service.execute(new Tracker(countDownLatch));
        countDownLatch.countDown();
        while (true) {
            countDownLatch.await();
            Tracker.decrease = !Tracker.decrease;
            int counterBeforeSleep = Tracker.counter;
            System.out.println("Cambiando orientación: " + (Tracker.decrease ? "dec" : "asc") + ", actual=" + counterBeforeSleep);
            Thread.sleep(1000);
            int counterAfterSleep = Tracker.counter;
            if ((!Tracker.decrease && counterBeforeSleep > counterAfterSleep) || (Tracker.decrease && counterBeforeSleep < counterAfterSleep))
                throw new RuntimeException(Thread.currentThread().getName() +
                        ":Inconsistencia de valores:" + counterBeforeSleep + " < " + counterAfterSleep + ", Dirección: " +
                        (Tracker.decrease ? "dec" : "asc"));

        }
    }


    static class Tracker implements Runnable {
        public  static int counter = 0;

        public  static boolean decrease = true;
        private final CountDownLatch countDownLatch;

        public Tracker(CountDownLatch countDownLatch) {
            this.countDownLatch = countDownLatch;
        }

        @Override
        public void run() {
            System.out.println("Tracker:" + Thread.currentThread().getName());
            countDownLatch.countDown();
            try {
                countDownLatch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            while (true) {
                counter = decrease ? counter - 1 : counter + 1;
            }
        }
    }
}