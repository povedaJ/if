package ac.ucr.b96086.practicaExam2.concurrency.advance.common;

public class Response {

    private String type;
    private String payload;

    public void setType(String type) {
        this.type = type;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public Response() {
    }

    public Response(String type, String payload) {
        this.payload = payload;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String getPayload() {
        return payload;
    }

    public static class ResponseBuilder {

        private String type;
        private String payload;

        public static ResponseBuilder newBuilder() {
            return new ResponseBuilder();
        }

        public ResponseBuilder isSuccess() {
            type = "OK";
            return this;
        }

        public ResponseBuilder isError() {
            type = "ERROR";
            return this;
        }

        public ResponseBuilder withPayload(String payload) {
            this.payload = payload;
            return this;
        }

        public Response build() {
            return new Response(type, payload);
        }
    }
}
