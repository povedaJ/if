package ac.ucr.b96086.practicaExam2.concurrencia1;

import static java.lang.String.format;

//ejercicio de la presentacion concurrencia 1

public class Racer implements Runnable {
    private String name;

    public Racer(String name) {
        this.name = name;
    }

    public void run() {
        System.out.println(format("%s starts the race", name));
        System.out.println(format("%s ends the race", name));
    }
}