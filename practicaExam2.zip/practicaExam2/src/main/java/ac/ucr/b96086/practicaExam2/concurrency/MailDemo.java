package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

public class MailDemo {
    public static void main(String[] args) {
        BlockingQueue<String> letters = new LinkedBlockingQueue<>();
        ExecutorService service = Executors.newCachedThreadPool();
        service.submit(new LetterWriter(letters));
        service.submit(new Postman(letters));
        service.submit(new Postman(letters));
        service.submit(new Postman(letters));
        service.shutdown();
    }
}

class Postman implements Runnable {
    private BlockingQueue<String> letters;
    private Random random = new Random();

    public Postman(BlockingQueue<String> letters) {
        this.letters = letters;
    }

    @Override
    public void run() {
        while (true) {
            try {
                String letter = letters.take();
                System.out.printf("%s: Entregando carta %s, pendientes(%d)\n", Thread.currentThread().getName(),
                        letter, letters.size());
                Thread.sleep(random.nextInt(5000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}

class LetterWriter implements Runnable {
    private BlockingQueue<String> letters;
    private int count;
    private Random random = new Random();

    public LetterWriter(BlockingQueue<String> letters) {
        this.letters = letters;
    }

    @Override
    public void run() {

        while (true) {
            String letter = count++ + "_" + Thread.currentThread().getName();
            System.out.printf("Creando carta %s\n", letter);
            letters.add(letter);
            try {
                Thread.sleep(random.nextInt(2000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

