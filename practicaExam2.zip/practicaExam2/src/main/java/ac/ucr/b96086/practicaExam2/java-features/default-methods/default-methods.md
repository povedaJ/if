# Métodos por defecto y estáticos en las interfaces

---

## ¿Qué es una interfaz?

- Es un contrato que define los métodos que debe implementar una clase.
- No contienen implementación del todo.

---

## ¿Por qué necesitamos métodos con código en las interfaces?

- Para extender el comportamiento de una interfaz existente y no forzar a todas las subclases que extienden la interfaz, se crearon los métodos default.
- Esto hace los diseños existentes no se quiebren.

---

### Otras razones

- Extender la funcionalidad de las Interfaces para las expresiones lambda.
- Tener una pseudo-herencia múltiple.
- No necesitar depender de constructores para creación de instancias de la super-clase.

---

## Declarando un método default

- Lo primero que hay que hacer es utilizar la palabra reservada `default`.

---

````java

interface FilePersistence<T> {

    T toEntity(String content);

    String toJson(T entity);

    String buildFileName(T entity);

    default void store(String root, T entity) {
        System.out.println("Storing file");
    }
}
````

---

En este caso se tiene una interfaz para procesar archivos con distintos tipos de formato tomando como comportamiento genérico el guardado del archivo, que sería el mismo código para todos.

Al implementar la interfaz se puede tener un método default que no requiere implementar ni añadir lógica extra.

---

Suponga que se tiene una especificación de dicha clase.

````java
class JsonPersistence<T> implements FilePersistence<T> {
    T toEntity(String content) {/*Código de conversión*/}

    String toJson(T entity) {/*Código de conversión*/}
}
````

---

En dado caso no se requiere definir el método `store`; igual que las clases abstractas y este puede ser referenciado por la clase especificadora `JsonPersistence`.

Además de que se puede referenciar desde otras clases

---

````java

class FileManager {
    public static void main(String[] args) {
        Contact contact = new Contact();
        JsonPersistence persistence = new JsonPersistence();
        persistence.store("root path", contact);
    }
}
````

---

El uso más frecuente es proveer funcionalidad adicional sin quebrar las clases que la implementan.


---

## Multiples interfaces con los mismos métodos

- A veces se puede generar el conflicto cuando dos métodos poseen la misma firma y están en distintas interfaces.
- Para este caso se debe referenciar utilizando la clase a la que pertenece el método a llamar como prefijo de la sentencia

---

````java

public class DefaultMethodExample {
    interface Transport {
        void move(int meters);

        default void estimatedTime(int distance, int velocity) {
            System.out.println("Calculating estimated time");
        }
    }

    interface FlyingShip {
        default void estimatedTime(int distance, int velocity) {
            System.out.println("Calculating estimated time");
        }
    }

    static class Airplane implements Transport, FlyingShip {

        @Override
        public void move(int meters) {
        }

        @Override
        public void estimatedTime(int distance, int velocity) {
            Transport.super.estimatedTime(distance, velocity);
        }
    }
}

````

---

En el ejemplo anterior se utiliza la palabra reservada `super`, que en este caso tiene un funcionamiento similar al acostumbrado en la herencia, hacemos referencia a la interfaz padre

````
Transport.super.estimatedTime(distance, velocity);
````

---

## Métodos estáticos en las interfaces

- Desde Java 8 es posible agregar métodos estáticos en las interfaces
- Su comportamiento y utilidad es la misma que en una clase.

---

````java

interface FilePersistence<T> {

    T toEntity(String content);

    String toJson(T entity);

    String buildFileName(T entity);

    default void store(String root, T entity) {
        System.out.println("Storing file");
    }

    static String getRootPath() {
        return "this is a root path";
    }
}
````

---

## Diferencia con las clases abstractas

- Todas estas características se pueden aplicar con clases abstractas, lograr el mismo comportamiento.
- La principal ventaja de las interfaces es que permiten la herencia múltiple.
- Pero a diferencia de las clases abstractas estas no tienen:
    - Constructores: Al no tener variables de instancia no se puede inicializar información.
    - Estados: Desde una interfaz no se puede mantener un estado por la misma razón de no manejar variables de instancia
    - Comportamiento: No manejando estados implica no cambiar el comportamiento del objeto desde la interfaz.

---

## Referencias

- https://www.baeldung.com/java-static-default-methods