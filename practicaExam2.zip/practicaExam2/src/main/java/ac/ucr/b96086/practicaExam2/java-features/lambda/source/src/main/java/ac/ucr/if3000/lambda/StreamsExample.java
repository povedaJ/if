package ac.ucr.b96086.practicaExam2.java;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamsExample {

    void streamCreation() {

        String animals[] = new String[]{"Lion", "Tiger", "Zebra", "Elephant"};
        Stream<String> stream = Arrays.stream(animals);

        Stream<String> other = Stream.of("Dog", "Cat", "Mouse", "Rabbit");


        List<String> countries = Arrays.asList("Costa Rica", "Nicaragua", "El Salvador", "Puriscal");
        countries.stream();

        countries.parallelStream();
    }

    void streamOperations() {
        List<Person> persons = Arrays.asList(
                new Person("Abel",
                        "García",
                        LocalDate.of(1990, Month.APRIL, 23),
                        null,
                        Arrays.asList(new Person.Phone("+506", "", "81234567")),
                        new ArrayList<>()
                ), new Person("Ana",
                        "Pérez",
                        LocalDate.of(2000, Month.OCTOBER, 3),
                        "ana@email.com",
                        Arrays.asList(new Person.Phone("+506", "", "87654321")),
                        new ArrayList<>()
                )

        );


        List<Person> result = persons.stream()
                .filter(person -> person.getDateOfBirth()
                        .compareTo(LocalDate.of(2000, Month.JANUARY, 1)) > 0)
                .collect(Collectors.toList());


    }

}
