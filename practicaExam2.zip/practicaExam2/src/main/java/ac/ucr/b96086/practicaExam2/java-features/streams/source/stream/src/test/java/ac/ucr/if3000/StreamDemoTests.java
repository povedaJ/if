package ac.ucr.b96086.practicaExam2.java;

import ac.ucr.if3000.streams.StreamDemo;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StreamDemoTests {


    @Test
    public void testIntStream(){
        StreamDemo demo = new StreamDemo();
        assertEquals(demo.countList(),6,"La lista no está bien contada");
    }
    @Test
    public void testIntStream2(){
        StreamDemo demo = new StreamDemo();
        assertEquals(demo.countList(),7,"La lista no está bien contada");
    }
}
