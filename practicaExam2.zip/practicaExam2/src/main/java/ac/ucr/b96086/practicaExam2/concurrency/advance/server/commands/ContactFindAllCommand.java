package ac.ucr.b96086.practicaExam2.concurrency.advance.server.commands;

import ac.ucr.if3000.concurrency.advance.common.domain.Contact;
import ac.ucr.if3000.concurrency.advance.common.json.Json;
import ac.ucr.if3000.concurrency.advance.server.service.ContactService;

import java.util.List;

public class ContactFindAllCommand implements Command {
    @Override
    public String execute(String payload) {
        ContactService service = new ContactService();
        List<Contact> contacts = service.findAll();
        return Json.convert(contacts);
    }
}
