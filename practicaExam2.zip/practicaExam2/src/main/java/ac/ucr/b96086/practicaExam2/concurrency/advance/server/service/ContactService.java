package ac.ucr.b96086.practicaExam2.concurrency.advance.server.service;


import ac.ucr.if3000.concurrency.advance.common.domain.Contact;
import ac.ucr.if3000.concurrency.advance.common.persistence.Persistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceContext;

import java.util.List;

public class ContactService {

    private final Persistence<Contact> persistence;

    public ContactService() {
        this.persistence = PersistenceContext.getPersistenceInstance(Contact.class);
    }

    public void save(Contact contact) {
        // validar que sea un número válido (mayor a 8 dígitos)
        // nombre válido mayor a 3 letras
        persistence.save(contact);
    }

    public List<Contact> findAll() {
        return persistence.findAll();
    }

    public void deleteContact(Contact contact) {
        persistence.delete(contact.getId());
    }
}
