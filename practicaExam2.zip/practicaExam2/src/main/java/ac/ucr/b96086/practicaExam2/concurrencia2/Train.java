package ac.ucr.b96086.practicaExam2.concurrencia2;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Train {

    public static void main(String[] args) {
        new Train().start();
    }
    public void start() {
        Executors.newScheduledThreadPool(10).execute(this::chuchu);
        new TicketChequer().start();
    }

    private void chuchu() {
        int duration = new Random().nextInt(10) + 5;
        System.out.printf("El tren esta arrancando el viaje durará %d segundos \n", duration);
        try {
            Thread.sleep(duration * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("El viaje a terminado, vuelva pronto");
    }
}


class TicketChequer {
    public void start() {
        Executors.newScheduledThreadPool(10).schedule(() ->
                System.out.println("Revisando tiquetes"), 2, TimeUnit.SECONDS);
    }
}