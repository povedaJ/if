package ac.ucr.b96086.practicaExam2.concurrency;


import java.time.Instant;
import java.util.concurrent.*;

public class RacerWithFuture {

    private RacerFuture racer1, racer2, racer3;

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        RacerWithFuture race = new RacerWithFuture();
        race.prepareRacer();
        race.startRace();
    }

    void prepareRacer() {
        racer1 = new RacerFuture("La Pulga");
        racer2 = new RacerFuture("El Fenómeno");
        racer3 = new RacerFuture("El Bicho");
    }

    public void startRace() throws ExecutionException, InterruptedException {
        ExecutorService threadExecutor = Executors.newCachedThreadPool();
        Future<Long> future1 = threadExecutor.submit(racer1);
        Future<Long> future2 = threadExecutor.submit(racer2);
        Future<Long> future3 = threadExecutor.submit(racer3);

        System.out.println("Racer 1: " + future1.get());
        System.out.println("Racer 2: " + future2.get());
        System.out.println("Racer 3: " + future3.get());
        threadExecutor.shutdown();
    }
}

class RacerFuture implements Callable<Long> {
    private String name;

    public RacerFuture(String name) {
        this.name = name;
    }

    @Override
    public Long call() {
        long initialTime = Instant.now().getNano();
        System.out.printf("%s starts to run\n", name);
        System.out.printf("%s ends to run\n", name);
        return Instant.now().getNano() - initialTime;
    }
}
