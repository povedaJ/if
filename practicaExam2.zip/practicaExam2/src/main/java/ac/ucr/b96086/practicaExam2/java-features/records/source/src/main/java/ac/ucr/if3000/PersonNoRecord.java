package ac.ucr.b96086.practicaExam2.java;

import java.time.LocalTime;
import java.util.Objects;

public class PersonNoRecord {

    private String cardId;
    private String name;
    private String lastName;
    private LocalTime dateOfBird;

    public PersonNoRecord(String cardId, String name, String lastName, LocalTime dateOfBird) {
        this.cardId = cardId;
        this.name = name;
        this.lastName = lastName;
        this.dateOfBird = dateOfBird;
    }

    public String getCardId() {
        return cardId;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalTime getDateOfBird() {
        return dateOfBird;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonNoRecord that = (PersonNoRecord) o;
        return cardId.equals(that.cardId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cardId);
    }
}
