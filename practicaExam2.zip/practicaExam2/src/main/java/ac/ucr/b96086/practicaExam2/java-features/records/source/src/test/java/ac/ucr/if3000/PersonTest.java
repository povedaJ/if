package ac.ucr.b96086.practicaExam2.java;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class PersonTest {


    @Test
    public void testPersonConstructor() {
        var cardId = "123-456-7";
        var name = "Max";
        var lastName = "Power";
        var dob = LocalDate.of(1990, 12, 12);
        var person = new Person(cardId, name, lastName, dob);

        assertEquals(person.cardId(), cardId, "La cédula no es igual");
        assertEquals(person.name(), name, "El nombre no es igual");
        assertEquals(person.lastName(), lastName, "El apellido no es igual");
        assertEquals(person.dateOfBird(), dob, "La fecha de nacimiento no es igual");
    }
    @Test
    public void testPersonEquals() {
        var cardId = "123-456-7";
        var name = "Max";
        var lastName = "Power";
        var dob = LocalDate.of(1990, 12, 12);
        var dob2 = LocalDate.of(1991, 12, 12);
        var person = new Person(cardId, name, lastName, dob);
        var person2 = new Person(cardId, name, lastName, dob2);
        var person3 = new Person(cardId, name, lastName, dob);

        assertFalse(person.equals(person2));
        assertTrue(person.equals(person3));

    }
    @Test
    public void toStringTest() {
        var cardId = "123-456-7";
        var name = "Max";
        var lastName = "Power";
        var dob = LocalDate.of(1990, 12, 12);
        var person = new Person(cardId, name, lastName, dob);

        System.out.println(person);

    }
}
