package ac.ucr.b96086.practicaExam2.java;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class App {
//    Esto no es permitido
//    var a = "";

    public static void main(String[] args) {

        var hello = "Hello World!";

        var numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        System.out.println(hello);

        var var = "var";
        var bar = var;

//        var noType;
//        noType=1;
        Function<String, Integer> strToInt = (param) -> Integer.parseInt(param) * 2;
        List<String> list = new ArrayList<>();
        var varList = new ArrayList<>();

    }

//    Esto tampoco es permitido
//    public void test(var param){ }
}
