package ac.ucr.b96086.practicaExam2.concurrency.advance.server.commands;

public interface Command {
    <R> R execute(String payload);
}
