package ac.ucr.b96086.practicaExam2.concurrency.advance.async;

public interface Async<V> {
    V execute();

    void onSuccess(V response);

    void onFail(Throwable fail);
}
