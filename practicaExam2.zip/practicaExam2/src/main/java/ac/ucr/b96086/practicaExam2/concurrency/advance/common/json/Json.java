package ac.ucr.b96086.practicaExam2.concurrency.advance.common.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.List;

public class Json {

    public static <E> String convert(E entity) {
        try {
            return mapper().writerWithDefaultPrettyPrinter().writeValueAsString(entity);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <E> E readValue(String entity, Class<E> clazz) {
        try {
            return mapper().readValue(entity, clazz);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static <E> E readValue(String entity, TypeReference<E> valueTypeRef) {
        try {
            return mapper().readValue(entity, valueTypeRef);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static <E> List<E> readValueAsCollection(String entity, Class<E> clazz) {
        try {
            ObjectMapper mapper = mapper();
            Class<?> clz = Class.forName(clazz.getName());
            JavaType type = mapper.getTypeFactory().constructCollectionType(List.class, clz);
            List<E> result = mapper.readValue(entity, type);
            return result;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private static ObjectMapper mapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return mapper;

    }
}
