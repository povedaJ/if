package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

 class Bar {
    private Lock lock = new ReentrantLock();
    private Random random = new Random();

    public void getBeer(Client client) {
        try {
            lock.lock();
            System.out.printf("Bar: Off course %s\n", client.getName());
            Thread.sleep(random.nextInt(2000));
        } catch (InterruptedException ignored) {

        } finally {
            System.out.printf("Bar: %s take your beer\n", client.getName());
            lock.unlock();
        }
    }
}
public class BarDemo {
    public static void main(String[] args) {
        Bar bar = new Bar();
        ExecutorService service = Executors.newCachedThreadPool();
        service.submit(new Client("John", bar));
        service.submit(new Client("Dave", bar));
        service.submit(new Client("Gabe", bar));
        service.submit(new Client("Robi", bar));
        service.submit(new Client("Marg", bar));
        service.submit(new Client("Till", bar));
    }
}
class Client implements Runnable {
    private final Bar bar;
    private final String name;
    private final Random random = new Random();

    public Client(String name, Bar bar) {
        this.name = name;
        this.bar = bar;
    }

    @Override
    public void run() {
        System.out.printf("%s: is in the bar\n", name);
        while (true) {
            try {
                Thread.sleep(random.nextInt(10000));
                System.out.printf("%s: may I have a beer?\n", name);
                bar.getBeer(this);
            } catch (InterruptedException ignored) {
            }
        }
    }

    public String getName() {
        return name;
    }
}



