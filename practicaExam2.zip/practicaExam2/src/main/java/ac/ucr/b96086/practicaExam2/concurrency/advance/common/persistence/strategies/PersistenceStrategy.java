package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence.strategies;

public enum PersistenceStrategy {
    XML,
    JSON,
    SOCKET;
}
