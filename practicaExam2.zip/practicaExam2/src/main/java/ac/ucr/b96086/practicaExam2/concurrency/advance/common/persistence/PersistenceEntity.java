package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence;

public interface PersistenceEntity {

    String getId();
}
