package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConcurrentObject {
    public static void main(String[] args) throws InterruptedException {
        List numbers = new Vector();
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(new AddNumbers(numbers));
        service.execute(new AddNumbers(numbers));
        while (true) {
            Thread.sleep(5000);
            System.out.println(numbers.size());
        }
    }
}


class AddNumbers implements Runnable {
    private List<Integer> numbers;

    public AddNumbers(List<Integer> numbers) {
        this.numbers = numbers;
    }

    @Override
    public void run() {
        for (int count = 1000; count > 0; count--)
            numbers.add(new Random().nextInt(10));
    }
}