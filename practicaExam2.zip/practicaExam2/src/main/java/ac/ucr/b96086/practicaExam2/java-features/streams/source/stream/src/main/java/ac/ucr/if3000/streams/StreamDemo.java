package ac.ucr.b96086.practicaExam2.java;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class StreamDemo {


    public Long countList() {

//        List<String> countries = Arrays.asList("Costa Rica", "Nicaragua", "El Salvador", "Puriscal");
//        countries.stream();
        IntStream numbers = Arrays.stream(new int[]{1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 5, 6});
        numbers.distinct().reduce(0,(a,b)-> a+b);
        //long count = disc.count();

        return 0L;
    }

    public void mapCountries(){
        List<String> countries = Arrays.asList("Costa Rica", "Nicaragua", "El Salvador", "Puriscal");
        countries.stream().map( name -> new Country(name));
    }

    static record Country(String country){
    }
}

