package ac.ucr.b96086.practicaExam2.concurrency.advance.server.socket;


import ac.ucr.if3000.concurrency.advance.async.AsyncRunner;
import ac.ucr.if3000.concurrency.advance.common.Request;
import ac.ucr.if3000.concurrency.advance.common.Response;
import ac.ucr.if3000.concurrency.advance.common.json.Json;
import ac.ucr.if3000.concurrency.advance.server.commands.MappingCommands;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public Server(int port) {

        try (ServerSocket serverSocket = new ServerSocket(port); serverSocket) {
            while (true) {
                System.out.println("Esperando una conexión");
                Socket socket = serverSocket.accept();
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                String request = (String) in.readObject();
                processRequest(request, socket);
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private void processRequest(String input, Socket socket) {
        AsyncRunner.newRunner().onExecute(() -> {
            Request request = Json.readValue(input, Request.class);
            String payload = MappingCommands.getCommand(request.getPath()).execute(request.getPayload());
            Response response = Response.ResponseBuilder.newBuilder().isSuccess().withPayload(payload).build();
            processResponse(response, socket);
            return null;
        }).onError((e) -> {
            processResponse(Response.ResponseBuilder.newBuilder().isError().withPayload("Error procesando la petición").build(), socket);
        }).run();

    }

    private void processResponse(Response response, Socket socket) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(Json.convert(response));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
