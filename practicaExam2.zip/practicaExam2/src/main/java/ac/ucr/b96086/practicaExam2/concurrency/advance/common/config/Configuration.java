package ac.ucr.b96086.practicaExam2.concurrency.advance.common.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;

public class Configuration {

    public static final String CONFIG_SERVER = "server.properties";
    public static final String CONFIG_CLIENT = "client.properties";
    public static String STRATEGY = "app.persistence.strategy";
    public static String ROOT = "app.persistence.root";
    public static String HOST = "app.socket.host";
    public static String PORT = "app.socket.port";
    private static Properties applicationProp = new Properties();

    public static String config;


    public static void loadConfiguration(String config) {
        try (InputStream input = Configuration.class.getClassLoader().getResourceAsStream(config)) {
            applicationProp.load(Objects.requireNonNull(input));
        } catch (IOException ex) {
            throw new RuntimeException("Unable to load application properties configuration file", ex);
        }
    }


    public static String get(String name) {
        return applicationProp.get(name).toString();
    }
}
