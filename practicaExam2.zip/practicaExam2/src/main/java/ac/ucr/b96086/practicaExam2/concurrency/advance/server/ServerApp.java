package ac.ucr.b96086.practicaExam2.concurrency.advance.server;

import ac.ucr.if3000.concurrency.advance.common.config.Configuration;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceContext;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.PersistenceStrategy;
import ac.ucr.if3000.concurrency.advance.server.socket.Server;

import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.*;

public class ServerApp {

    public static void main(String[] args) {
        Configuration.loadConfiguration(Configuration.CONFIG_SERVER);
        PersistenceContext.setRoot(Configuration.get(ROOT));
        PersistenceContext.setStrategy(PersistenceStrategy.valueOf(Configuration.get(STRATEGY)));

        new Server(Integer.parseInt(Configuration.get(PORT)));
    }
}
