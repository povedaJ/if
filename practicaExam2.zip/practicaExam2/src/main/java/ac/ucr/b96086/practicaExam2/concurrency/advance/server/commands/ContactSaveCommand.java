package ac.ucr.b96086.practicaExam2.concurrency.advance.server.commands;

import ac.ucr.if3000.concurrency.advance.common.domain.Contact;
import ac.ucr.if3000.concurrency.advance.common.json.Json;
import ac.ucr.if3000.concurrency.advance.server.service.ContactService;

public class ContactSaveCommand implements Command {

    @Override
    public String execute(String payload) {
        ContactService service = new ContactService();
        service.save(Json.readValue(payload, Contact.class));
        return "OK";
    }

}
