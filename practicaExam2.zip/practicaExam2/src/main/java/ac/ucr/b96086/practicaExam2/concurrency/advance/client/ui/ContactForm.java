package ac.ucr.b96086.practicaExam2.concurrency.advance.client.ui;


import ac.ucr.if3000.concurrency.advance.async.AsyncRunner;
import ac.ucr.if3000.concurrency.advance.common.config.Configuration;
import ac.ucr.if3000.concurrency.advance.common.domain.Contact;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceContext;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.PersistenceStrategy;
import ac.ucr.if3000.concurrency.advance.server.service.ContactService;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.stream.IntStream;

import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.*;

public class ContactForm extends Application {

    private final Button addButton = new Button();
    private final TextField nameField = new TextField();
    private final TextField surnameField = new TextField();
    private final DatePicker birthDatePicker = new DatePicker();

    ObservableList<Contact> contacts = FXCollections.observableArrayList();

    private final ContactService service = new ContactService();

    public static void main(String[] args) {
        Configuration.loadConfiguration(CONFIG_CLIENT);
        PersistenceContext.setRoot(Configuration.get(ROOT));
        PersistenceContext.setStrategy(PersistenceStrategy.valueOf(Configuration.get(STRATEGY)));
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Label nameLabel = new Label("Nombre");
        Label surnameLabel = new Label("Apellidos");
        Label birthDateLabel = new Label("Fecha de Nacimiento");
        addButton.setText("Agregar");

        addButton.setOnAction(event -> createContact());

        GridPane form = buildForm(nameLabel, nameField, surnameLabel, surnameField, birthDateLabel, birthDatePicker, addButton);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(5, 5, 5, 50));
        layout.getChildren().addAll(form, buildListView());
        Scene scene = new Scene(layout, 600, 600);

        primaryStage.setTitle("Contactos!");
        primaryStage.setScene(scene);
        primaryStage.show();
        reloadContacts();
    }

    private void createContact() {
        AsyncRunner.<Contact>newRunner()
                .onExecute(
                        () -> {
                            System.out.println(Thread.currentThread().getName());
                            setDisable(true);
                            Contact contact = new Contact();
                            contact.setName(nameField.getText());
                            contact.setSurname(surnameField.getText());
                            contact.setBirthDate(birthDatePicker.getValue());
                            service.save(contact);
                            try {
                                Thread.sleep(10000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            return contact;
                        }
                ).onSuccess(
                        (contact) -> {
                            setDisable(false);
                            nameField.clear();
                            surnameField.clear();
                            Platform.runLater(this::reloadContacts);
                        }
                ).onError((exception) -> {
                    setDisable(false);
                }).run();


    }

    private void setDisable(boolean enabled) {
        nameField.setDisable(enabled);
        surnameField.setDisable(enabled);
        addButton.setDisable(enabled);
        birthDatePicker.setDisable(enabled);
    }

    private void reloadContacts() {
        contacts.clear();
        contacts.addAll(service.findAll());
    }

    private ListView<Contact> buildListView() {
        ListView<Contact> listView = new ListView<>(contacts);
        listView.setMaxSize(500, 500);

        return listView;
    }

    private GridPane buildForm(Control... controls) {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10, 10));
        IntStream.range(0, controls.length)
                .forEach(index ->
                        grid.add(controls[index], index % 2, index / 2, 1, 1));

        return grid;
    }
}