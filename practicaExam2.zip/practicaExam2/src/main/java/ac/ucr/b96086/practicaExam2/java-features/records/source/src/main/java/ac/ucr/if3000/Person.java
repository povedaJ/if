package ac.ucr.b96086.practicaExam2.java;

public record Person(String cardId, String name, String lastName, LocalDate dateOfBird){
    public static final String NO_CARD_ID = "no-card-id";

    public static Person basic(String name) {
        return new Person(name);
    }

    public Person(String name) {
        this(null, name, null, null);
    }
}


//class PersonChild extends Person{
//    public PersonChild(String name) {
//        super(name);
//    }
//}