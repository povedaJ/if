package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Race {
    private Racer racer1, racer2, racer3;

    public static void main(String[] args) {
        Race race = new Race();
        race.prepareRacer();
        race.startRace();
    }

    void prepareRacer() {
        racer1 = new Racer("La Pulga");
        racer2 = new Racer("El Fenómeno");
        racer3 = new Racer("El Bicho");
    }

    void startRace() {
        ExecutorService threadExecutor = Executors.newCachedThreadPool();
        threadExecutor.execute(racer1);
        threadExecutor.execute(racer2);
        threadExecutor.execute(racer3);
        threadExecutor.shutdown();
    }
}

 class Racer implements Runnable {
    private String name;

    public Racer(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.printf("%s starts the race\n", name);
        System.out.printf("%s ends the race\n", name);
    }
}