package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence.strategies;

import ac.ucr.if3000.concurrency.advance.common.Request;
import ac.ucr.if3000.concurrency.advance.common.Response;
import ac.ucr.if3000.concurrency.advance.common.config.Configuration;
import ac.ucr.if3000.concurrency.advance.common.json.Json;
import ac.ucr.if3000.concurrency.advance.common.persistence.Persistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceEntity;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.HOST;
import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.PORT;

public class SocketPersistence<E extends PersistenceEntity> implements Persistence<E> {
    protected final Class<E> clazz;

    private String host = Configuration.get(HOST);
    private int port = Integer.parseInt(Configuration.get(PORT));

    public SocketPersistence(Class<E> clazz) {
        this.clazz = clazz;
    }

    @Override
    public boolean save(E entity) {
        Request request = Request.RequestBuilder.newBuilder()
                .path(clazz.getSimpleName() + "/save")
                .payload(Json.convert(entity))
                .build();
        Response response = sendRequest(request);

        return response.getType().equals("OK");

    }

    @Override
    public boolean delete(String id) {
        return false;
    }

    @Override
    public List<E> findAll() {
        Response response = sendRequest(Request.RequestBuilder.newBuilder()
                .path(clazz.getSimpleName() + "/findAll")
                .build());
        System.out.println(response.getPayload());
        return Json.readValueAsCollection(response.getPayload(), clazz);
    }

    public Response sendRequest(Request request) {

        try (Socket clientSocket = new Socket(host, port); clientSocket;) {

            ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.writeObject(Json.convert(request));
            ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
            return Json.readValue(in.readObject().toString(), Response.class);
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}
