package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence.strategies;


import ac.ucr.if3000.concurrency.advance.common.json.Json;
import ac.ucr.if3000.concurrency.advance.common.persistence.Persistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceEntity;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class JsonPersistence<E extends PersistenceEntity> extends FilePersistence<E> implements Persistence<E> {

    public JsonPersistence(Class<E> clazz, String root) {
        super(root, clazz, "json");
    }

    @Override
    public boolean save(E entity) {
        try {
            storeFile(entity);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(String id) {
        return deleteFile(id);
    }

    @Override
    public List<E> findAll() {
        return this.findAllFiles(fileType).stream()
                .map(entity -> readValue(entity, super.clazz))
                .collect(Collectors.toList());
    }

    @Override
    protected String convert(PersistenceEntity entity) {
        return Json.convert(entity);
    }

    private E readValue(String entity, Class<E> clazz) {
        return Json.readValue(entity, clazz);
    }
}
