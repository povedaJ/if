# Streams

---

- Se introdujeron en la version 8 de Java.
- Su objetivo es el procesamiento de secuencias de elementos.
- Pueden ser creados por diferentes elementos.
    - Colecciones.
    - Arreglos.
    - Clases utilitarias.
- Permite tratar las colecciones de datos como si se tratara de las etapas de un proceso de Extraer Transformar y Cargar(ETL)

---

## Stream API

- El paquete base es `java.util.stream` que contiene clases para el procesamiento de secuencias de elementos.
- El elemento principal es la interfaz `Stream<T>`

---

### Creación de un Stream

- Puede ser creado con los métodos estáticos `of()` y `stream()`

````
String animals[]= new String[]{"Lion","Tiger", "Zebra","Elephant"};
Stream<String> stream = Arrays.stream(animals);

Stream<String> other = Stream.of("Dog","Cat", "Mouse","Rabbit");
````

---

- Adicionalmente otro método `stream` es agregado a la interfaz Collection que permite crear instancias de `Stream` desde cualquier colección

````
List<String> countries = Arrays.asList("Costa Rica", "Nicaragua", "El Salvador", "Puriscal");
countries.stream();
````

---

### Creación de un Stream Multi-Hilos

````
countries.parallelStream();
````

---

### Procesamiento de Operaciones

- Se dividen en dos tipos de operaciones:
    - Operaciones intermedias: Estas operaciones permiten encadenamiento
    - Operaciones de finalización: Retornan un resultado
    - Ambos tipos de operaciones no cambian la fuente.

---


Por ejemplo:

````
Stream<Integer> numbers = Arrays.stream(1,1,1,2,2,2,3,3,3,4,4,5,6);
long count = numbers.distinct().count();

````

---

- En este caso `distinct`, es una operación intermedia. Crea un nuevo Stream de elementos únicos del anterior stream.
- Mientras que el `count` es una operación de finalización, puesto que retorna el número de registros que contiene el Stream.

---

### Iteraciones

- El API de Stream ayuda a substituir `for`, `for-each`, `ciclos while`.
- Permitiendo concentrarse en la lógica de la operación.

---

````
for (String string : countries) {
    if (string.contains("Costa Rica")) {
        return true;
    }
}

````

---


Se puede substituir por:

````
boolean isExist = countries.stream().anyMatch(element -> element.contains("Costa Rica"));
````

---

### Filtrado

- El método `filter()` permite evaluar un flujo de datos que satisfaga un predicado y crear un nuevo Stream con los valores que cumplieron el predicado.

````
Stream<String> stream = countries.stream().filter(country -> country.contains("r"));
````

- Aquí se está creando un Stream de la lista de países, luego se está aplicando un predicado que valida el país que contenta una `r`

---

### Mapeo o Conversión

- Se puede aplicar la conversión de datos a un Stream, generando un nuevo Stream de un nuevo tipo. Para esto se utiliza el método `map`.

````
List<String> countries = Arrays.asList("Costa Rica", "Nicaragua", "El Salvador", "Puriscal");
countries.stream().map( name -> new Country(name));
````

- En el caso anterior, se está creando un nuevo Stream<Country>, con base en un Stream<String>.

---

#### Aplanando listas detalladas

- Si se tiene un Stream y a su vez cada nodo tiene su propio Stream, es posible crear un único Stream con todos los nodos de la lista

````
Stream<Phone> stream = contacts.stream().flatMap(contact -> contact.getPhones().stream());
````

- Por cada contacto se está extrayendo el Stream de los números telefónicos y pasando el Stream<Phone> para luego crear un nuevo Stream<Phone> con todos los números telefónicos de todos los contactos.

---

### Emparejamiento

- Para validar una lista y revisar que todos o algunos elementos cumplan con alguna condición se puede utilizar las funciones matching

````
boolean allPossitives=numbers.stream().allMatch(number-> number > 0);
boolean atLeastOnePossitive=numbers.stream().anyMatch(number-> number > 0);
boolean nonePossitives=numbers.stream().noneMatch(number-> number > 0);
````

---

- Estas operaciones de finalización evalúan el predicado y con base en él indican un resultado booleano
    - `allMatch`: todos deben cumplir con el predicado.
        - Todas las personas en la lista deben ser mayores de edad.
        - Todas las personas deben tener un monto mínimo.
    - `anyMatch`: Al menos un registro coincide con la búsqueda.
        - ¿Existe el carro por número de placa?
        - ¿El pasajero está en este auto bus?
    - `noneMatch`: Ninguno cumple con el predicado
        - Falta algún pasajero de entregar sus boletos
        - Hay algún cobro pendiente de este año

---

#### anyMatch y noneMatch para streams vacíos

- Hay un caso especial que se debe considerar que es cuando evaluamos Strings vacíos

````
Stream.empty().allMatch(Objects::nonNull); // true
Stream.empty().anyMatch(Objects::nonNull); // false
        
````

---

- Cuando se evalúa un `Stream` vacío el comportamiento es difícil de predecir.
- A pesar de que el ejemplo luzca poco probable, hay que tomar en cuenta que siempre se está programando en un contexto con datos cambiantes. Eventualmente se va a programar una validación como esta y
  se puede tener el caso donde la lista está vacía.

---

### Reducción

- También se pueden realizar sumatorias o procesos que acumulen algún valor y cuyo resultado final sea un valor único.

````
Integer totalAmount = transactions.stream().reduce(0, (a, b) -> a.getAmount() + b.getAmount());
````

---

- En este ejemplo se está recorriendo una hipotética lista de transacciones para saber el monto total.
- El método `reduce` en este caso recibe dos parámetros, el primero es el valor inicial el segundo es el predicado que realiza la sumatoria.

---

## Colectando datos

- Hay que recordad que esto no es una lista de resultados finales, esto es un `Stream` que se utiliza solamente para procesar los datos.
- Por lo que también provee un método para transformar los datos a una Colección, Mapa o una simple lista de Strings.

---

````
List<Person> result = person.stream().filter(person -> person.getEmail()!=null).collect(Collectors.toList());
````

- En este caso después de un procesamiento de datos, se está convirtiendo el `Stream<Person>` a un `List<Person>`.

---

## Combinando Operaciones

- Es posible combinar múltiples operaciones intermedias para luego procesar una operación de finalización.
- Por ejemplo: Se puede imaginar que existe una estructura como esta

---

````java
public class Person {
    private String name;
    private String lastName;
    private LocalDate dateOfBirth;
    private String email;
    private List<Phone> phones;
    private List<Call> calls;

    static class Phone {
        private String countryCode;
        private String areaCode;
        private String number;
    }

    static class Call {
        private Phone phone;
        private LocalTime when;
    }
}
````

---

- Ahora suponga que se tiene una lista con información variada de esta entidad Persona
    - Personas con todos los datos personales y con varios teléfonos.
    - Personas sin correo electrónico y sin teléfonos.
    - Personas con todos los datos personales, con teléfonos y con múltiples llamadas.
    - Personas menores de edad con múltiples combinaciones.

---

- Con esa base de datos es posible realizar múltiples búsquedas. Dependiendo de las reglas del negocio. He aquí algunos ejemplos(Asumamos la existencia de algunos métodos para validar la reglas)

---

- Filtrar los nombres de las personas menores de edad que llamen entre las 12 y las 4 de la mañana.

````java
     List<String> result=persons.stream()
        .filter(p->p.isUnderage())
        .filter(p->p.getCalls().stream().anyMatch(c->c.callBetween(0,4)))
        .map(Person::getName)
        .collect(Collectors.toList());
````

---

- Teléfonos de las personas que no tengan correo electrónico y sean mayores de 50 años.

````java
     List<Person.Phone>result=persons.stream()
        .filter(p->p.isGreaterThan(50))
        .filter(p->p.getEmail()!=null)
        .flatMap(p->p.getPhones())
        .collect(Collectors.toList());
````

---

## Referencias

- https://www.baeldung.com/java-streams
- https://www.baeldung.com/java-8-streams-introduction
- https://www.belikesoftware.com/en/java-8-streams/#:~:text=Los%20Streams%20en%20java%20son,en%20la%20etapa%20de%20transformaci%C3%B3n.