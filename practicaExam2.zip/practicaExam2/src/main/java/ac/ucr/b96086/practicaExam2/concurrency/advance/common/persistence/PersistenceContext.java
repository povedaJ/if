package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence;


import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.JsonPersistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.PersistenceStrategy;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.SocketPersistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.XmlPersistence;

public class PersistenceContext {

    private static String root;

    private static PersistenceStrategy strategy;

    public static void setStrategy(PersistenceStrategy strategy) {
        PersistenceContext.strategy = strategy;
    }

    public static String getRoot() {
        if (root == null) {
            throw new RuntimeException("You need to define a root directory");
        }
        return root;
    }

    public static void setRoot(String root) {
        PersistenceContext.root = root;
    }


    public static <E extends PersistenceEntity> Persistence<E> getPersistenceInstance(Class<E> clazz) {
        switch (strategy) {
            case XML:
                return new XmlPersistence<E>(clazz, PersistenceContext.root);
            case JSON:
                return new JsonPersistence<E>(clazz, PersistenceContext.root);
            case SOCKET:
                return new SocketPersistence<E>(clazz);
        }

        throw new RuntimeException("Estrategia Inválida");
    }
}

