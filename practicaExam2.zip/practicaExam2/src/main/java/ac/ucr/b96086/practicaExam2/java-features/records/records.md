## Clases Record

---

- Introducida en la version 14.
- Redefine la implementación de Java Beans.
- Refuerzan la inmutabilidad.

---

## ¿Porqué existen los Java Beans?

- Contener objetos, transformarlos y transportar datos.
- Para pasar datos inmutables. La inmutabilidad ha sido uno de los mayores problemas que han resuelto los Java Beans.
- Controlar el acceso a los datos.

---

## ¿Cómo se forman los beans?

- Como ya es sabido, se crean introduciendo demasiado código repetitivo.
- Esto es solamente para formar una clase que no sea mutable.

---

````java

import java.time.LocalTime;
import java.util.Objects;

public class PersonNoRecord {

    private String cardId;
    private String name;
    private String lastName;
    private LocalTime dateOfBird;

    public PersonNoRecord(String cardId, String name, String lastName, LocalTime dateOfBird) {
        this.cardId = cardId;
        this.name = name;
        this.lastName = lastName;
        this.dateOfBird = dateOfBird;
    }

    public String getCardId() {
        return cardId;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalTime getDateOfBird() {
        return dateOfBird;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonNoRecord that = (PersonNoRecord) o;
        return cardId.equals(that.cardId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cardId);
    }
}
````

---

## ¿Cuál problema tienen los Java Beans?

- Puede que para un desarrollador Java esto sea una rutina normal, el ver clases con gran cantidad de líneas de código.
- Otra forma de reducir las líneas de código es implementando librerías de terceros([Lombok](https://projectlombok.org/)) que ayuden a reducir el código, sin embargo, esto no deja de añadir un poco
  más de complejidad al proyecto por más mínimo que sea, además de añadir una dependencia más.

---

- Sería natural si el lenguaje en sí proveyera una sintaxis para reducirlo o eliminar el código repetitivo.
- Además de no perder el objetivo de la clase que es mantener la información de una persona, que en este caso, son simples 4 datos.
- Poniéndolo en perspectiva, se van a necesitar cerca de 50 líneas de código para resolver el problema.

---


> ¿Acaso es eso justo para el desarrollador?

> ¿Tiene sentido mantener todo el código ahí prácticamente de por vida?

---

## Record al rescate

- Este tipo de estructuras reflejan un patrón definido por dos razones
    - Por el objetivo de la clase(Contener datos).
    - La estructura del Java Bean como tal.

---

- De ahí la razón de crear una estructura nueva que simplifique las cosas.
- Reduciendo las líneas de código al mínimo requerido.

---

````java
record Person(
        String cardId,
        String name,
        String lastName,
        LocalTime dateOfBird
) {
}
````

---

- Como se puede observar elimina el código repetitivo donde solo requiere enumerar el tipo y nombre de la variable.

---

### Constructor

- El constructor ahora está definido en la misma declaración de la clase.
- Esto refuerza el hecho de que un `record` no puede existir sin un constructor no vacío. No tendría razón de ser.
- El uso de esta clase no cambia en absoluto.

````
Person person = new Person("123","Eddie","The-head",LocalTime.now());
````

---

### Getters

- Se crean métodos públicos para acceder a los datos encapsulados por los beans

````
var personName = person.name();
````

---

### Equals

- El método equals de la clase también es autogenerado y en él incluyen todos los parámetros del constructor en su comparación.

---

````
pulic void testPersonEquals(){
        var cardId = "123-456-7";
        var name = "Max";
        var lastName = "Power";
        var dob = LocalDate.of(1990,12,12);
        var person = new Person(cardId,name,lastName,dob);
        var person2 = new Person(cardId,name,lastName,dob);
        
        assert(person.equals(person3));
}
````

---

### HashCode

- Este método es sobreescrito usando el mismo razonamiento, por lo tanto:

---

````
pulic void testPersonEquals(){
        var cardId = "123-456-7";
        var name = "Max";
        var lastName = "Power";
        var dob = LocalDate.of(1990,12,12);
        var person = new Person(cardId,name,lastName,dob);
        var person2 = new Person(cardId,name,lastName,dob);
        
        assert(person.hashCode()==person.hashCode());
}
````

---

- El código hash es generado utilizando los mismos parámetros del constructor.

---

### toString

- Una versión del toString es generada automáticamente, el ejemplo anterior se genera de la siguiente manera:

````
Person[cardId=123-456-7, name=Max, lastName=Power, dateOfBird=1990-12-12]
````

---

### Constructores

- Aunque no se puede ver explícitamente, un constructor es generado por defecto.
- Este también puede ser personalizable

---

````java
import java.time.LocalDate;
import java.util.Objects;

public record Person(String cardId, String name, String lastName, LocalDate dateOfBird) {

    public Person {
        Objects.requireNonNull(cardId);
        Objects.requireNonNull(name);
    }
}
````

---

- El constructor creado se puede personalizar, en este caso se está agregando un par de validaciones para no permitir que un objeto tipo `Person` no se cree sin ninguna cédula y nombre.
- Esto se hace utilizando un constructor sin argumentos.

---

- La sobre carga de constructores también es posible

````java
import java.time.LocalDate;

public record Person(String cardId, String name, String lastName, LocalDate dateOfBird) {

    public Person(String name) {
        this(null, name, null, null);
    }
}
````

---

### Miembros estáticos

- También es posible declarar variables y métodos estáticos.

---

````java
import java.time.LocalDate;

public record Person(String cardId, String name, String lastName, LocalDate dateOfBird) {
    public static final String NO_CARD_ID = "no-card-id";

    public static Person basic(String name) {
        return new Person(name);
    }

    public Person(String name) {
        this(null, name, null, null);
    }
}
````

---


En este caso se le puede dar el mismo uso que cualquier otra clase


---

### Relación con otras clases

- Los records no se pueden extender por lo tanto no podemos heredar sus propiedades a ninguno otra clase que pretenda heredar sus características.
- Tampoco se puede hacerlos extender de otras clases.
- Si se puede utilizar variables de otros records

## Conclusión

- El utilizar `record` facilita la implementación de objetos inmutables.
- Si no se está acostumbrado a trabajar con objetos inmutables puede tornarse complicado.
- Para objetos complejos manejar la inmutabilidad se puede complicarse si no se complementa con algunos patrones(por ejemplos builders).

---

## Referencias

- https://www.baeldung.com/java-record-keyword