package ac.ucr.b96086.practicaExam2.concurrency;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SynchronizedObject {

    public static void main(String[] args) throws InterruptedException {
        NumberBucket bucket = new NumberBucket();
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(new AddNumbersToBucket(bucket));
        service.execute(new AddNumbersToBucket(bucket));
        do {
            Thread.sleep(5000);
            System.out.println(bucket.size());
        } while (true);
    }
}


 class AddNumbersToBucket implements Runnable {
    private NumberBucket bucket;

    public AddNumbersToBucket(NumberBucket bucket) {
        this.bucket = bucket;
    }

    @Override
    public void run() {
        for (int count = 1000; count > 0; count--)
            bucket.add(new Random().nextInt(10));
    }
}

 class NumberBucket {
    private List<Integer> numbers;

    public NumberBucket() {
        numbers = new ArrayList<>();
    }

    public  void add(Integer value) {
        synchronized (this) {
            numbers.add(value);
        }
    }

    public int size() {
        synchronized (this) {
            return numbers.size();
        }
    }
}