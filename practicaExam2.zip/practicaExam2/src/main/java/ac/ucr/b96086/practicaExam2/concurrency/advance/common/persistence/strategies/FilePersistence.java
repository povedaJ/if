package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence.strategies;


import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceEntity;

import java.io.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public abstract class FilePersistence<E extends PersistenceEntity> {
    protected final String root;
    protected final String fileType;
    protected final Class<E> clazz;

    protected FilePersistence(String root, Class<E> clazz, String fileType) {
        this.root = root;
        this.fileType = fileType;
        this.clazz = clazz;
    }

    protected void storeFile(E entity) throws IOException {
        File fileName = new File(root, clazz.getCanonicalName() + "-" + entity.getId() + "." + fileType);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName)); writer) {
            writer.write(convert(entity));
        }
    }

    protected boolean deleteFile(String id) {
        File fileName = new File(root, id + "." + fileType);
        if (fileName.exists()) {
            return fileName.delete();
        } else return false;


    }

    protected List<String> findAllFiles(String extension) {
        File rootFolder = new File(root);
        return Arrays.stream(Objects.requireNonNull(rootFolder.listFiles()))
                .filter(file -> file.getName().startsWith(clazz.getCanonicalName() + "-") &&
                        file.getName().endsWith(extension))
                .map(this::readFile)
                .collect(Collectors.toList());

    }

    // https://www.baeldung.com/java-buffered-reader
    private String readFile(File file) {
        try (BufferedReader reader = Files.newBufferedReader(file.toPath())) {
            return reader.lines()
                    .collect(Collectors.joining(System.lineSeparator()));
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }

    protected abstract String convert(PersistenceEntity entity);
}
