# Referencias de métodos

---

- Fueron introducidas junto con las expresiones lambda pare reducir la verbosidad del código o el código repetitivo.
- Hay 4 formas de referencias de métodos
    - Métodos estáticos
    - Crear instancias de métodos de objetos particulares
    - Crear instancias de métodos de un objeto arbitrario de un objeto particular
    - Constructor

- Se trata de remover las cosas innecesarias en una expresión lambda limitando solo lo necesario.

---

## Referenciando métodos estáticos

Empecemos con un ejemplo simple

- Dado una lista de números

````java
        List<Integer> numbers=Arrays.asList(-1,2,-3,4,-5,6,-7,8,-9);

````

---


Podemos producir una nueva lista con los valores absolutos utilizando el método `Math.abs` combinando Streams con expresiones lambda

````java
        numbers.forEach(number->Math.abs(number));
````

---


Esto lo podemos reducir utilizando la referencia de métodos estáticos

````java
        numbers.forEach(Math::abs);
````

- Puesto que en la expresión lambda solamente estamos ejecutando una expresión, se dan las siguientes condiciones
    - Llamar a un único método. Una única expresión.
    - El método recibe la misma cantidad y el mismo tipo de parámetros que el método definido en la función lambda.

---

### Referenciando una instancia de un objeto en particular

Imaginemos que tenemos nuestra instancia comparadora de personas

````java
public class Person {

    private String name;
    private Integer age;
    // sets y gets de constructores
}

public class PersonComparator implements Comparator {

    @Override
    public int compare(Person a, Person b) {
        return a.getAge().compareTo(b.getAge());
    }

}

````

---


Ahora tenemos una lista de personas

```java
PersonComparator comp=new PersonComparator();
        persons.stream().sorted((a,b)->{comp.compare(a,b)});
```

A este punto podemos ver algunas coincidencias:

- Reciben la misma cantidad de parámetros
- Son del mismo tipo

---


Por lo que podemos aplicar el mismo concepto

```java
PersonComparator comp=new PersonComparator();
        persons.stream().sorted(comp::compare);
```

---

### Referenciando un método de instancia de un objeto arbitrario de un tipo en particular

- Similar al anterior, con la diferencia de que aquí no tenemos que crear ningún objeto previo.

````java
        List<Integer> numbers=Arrays.asList(-1,2,-3,4,-5,6,-7,8,-9);
````

---


Para ordenar la lista anterior se va a utilizar el método `compareTo` de la clase `Integer` por medio de una expresión lambda utlizando Streams

````java
numbers.stream().sorted((a,b)->a.compareTo(b));
````

---


En este caso, la expresión se puede simplificar debido a:

- Es una sola expresión
- Se invoca un método de una de las variables

````java
numbers.stream().sorted(Integer::compareTo);
````

---

### Referenciando un constructor

- Es muy similar a la referencia de método.
- En este caso solamente se utiliza la palabra reservada `new`

````java
       List<String> names=Arrays.asList("Bibidi","Babidi","Boo");
        names.stream().map(name->new Person(name));
````

---


Por lo que eliminando el código redundante y simplificando la expresión lambda podemos reducir la expresión a la siguiente manera

````java
       List<String> names=Arrays.asList("Bibidi","Babidi","Boo");
        names.stream().map(Person::new);
````

---

## Referencias

- https://www.baeldung.com/java-method-references