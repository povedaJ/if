package ac.ucr.b96086.practicaExam2.concurrency.advance;


import ac.ucr.if3000.concurrency.advance.common.config.Configuration;
import ac.ucr.if3000.concurrency.advance.common.domain.Contact;
import ac.ucr.if3000.concurrency.advance.common.domain.Phone;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceContext;
import ac.ucr.if3000.concurrency.advance.common.persistence.strategies.PersistenceStrategy;
import ac.ucr.if3000.concurrency.advance.server.service.ContactService;

import java.time.LocalDate;

import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.ROOT;
import static ac.ucr.if3000.concurrency.advance.common.config.Configuration.STRATEGY;

public class App {
    public static void main(String[] args) {
        PersistenceContext.setRoot(Configuration.get(ROOT));
        PersistenceContext.setStrategy(PersistenceStrategy.valueOf(Configuration.get(STRATEGY)));
        Contact contact = new Contact();
        contact.setBirthDate(LocalDate.now());
        contact.setName("Juan");
        contact.setSurname("Perez");
        Phone[] phones = new Phone[3];
        Phone p1 = new Phone();
        p1.setAreaCode("506");
        p1.setNumber("1233321");
        phones[0] = p1;
        phones[1] = p1;
        phones[2] = p1;
        contact.setPhones(phones);
        ContactService repository = new ContactService();
        repository.save(contact);
    }
}
