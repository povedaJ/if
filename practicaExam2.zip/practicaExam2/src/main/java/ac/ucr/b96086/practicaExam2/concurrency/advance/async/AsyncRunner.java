package ac.ucr.b96086.practicaExam2.concurrency.advance.async;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class AsyncRunner<R> {

    private Consumer<R> onSuccess;
    private Consumer<Object> onFail;
    private Supplier<R> onExecute;

    public static <V> AsyncRunner<V> newRunner() {
        return new AsyncRunner<V>();
    }

    public AsyncRunner<R> onSuccess(Consumer<R> function) {
        onSuccess = function;
        return this;
    }

    public AsyncRunner<R> onError(Consumer<Object> function) {
        onFail = function;
        return this;
    }

    public AsyncRunner<R> onExecute(Supplier<R> function) {
        onExecute = function;
        return this;
    }

    public void run() {
        AsyncManager.submit(new Async<R>() {
            @Override
            public R execute() {
                return onExecute.get();
            }

            @Override
            public void onSuccess(R response) {
                onSuccess.accept(response);

            }
            @Override
            public void onFail(Throwable error) {
                onFail.accept(error);

            }
        });
    }


}
