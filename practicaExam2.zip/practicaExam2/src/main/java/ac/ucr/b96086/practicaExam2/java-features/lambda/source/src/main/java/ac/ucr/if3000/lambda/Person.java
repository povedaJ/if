package ac.ucr.b96086.practicaExam2.java;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class Person {
    private String name;
    private String lastName;
    private LocalDate dateOfBirth;
    private String email;
    private List<Phone> phones;
    private List<Call> calls;

    public Person(String name) {
        this.name = name;
    }

    public Person(String name, String lastName, LocalDate dateOfBirth, String email, List<Phone> phones, List<Call> calls) {
        this.name = name;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phones = phones;
        this.calls = calls;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public String getEmail() {
        return email;
    }

    public List<Phone> getPhones() {
        return phones;
    }

    public List<Call> getCalls() {
        return calls;
    }


    static class Phone {
        private String countryCode;
        private String areaCode;
        private String number;

        public Phone(String countryCode, String areaCode, String number) {
            this.countryCode = countryCode;
            this.areaCode = areaCode;
            this.number = number;
        }

        public String getCountryCode() {
            return countryCode;
        }

        public String getAreaCode() {
            return areaCode;
        }

        public String getNumber() {
            return number;
        }
    }

    static class Call {
        private Phone phone;
        private LocalTime when;

        public Call(Phone phone, LocalTime when) {
            this.phone = phone;
            this.when = when;
        }

        public Phone getPhone() {
            return phone;
        }

        public LocalTime getWhen() {
            return when;
        }

        public boolean callBetween(int from, int to) {
            return when.getHour() >= from && when.getHour() < to;
        }
    }
}