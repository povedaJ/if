package ac.ucr.b96086.practicaExam2.concurrency.advance.common;

import java.util.Map;

public class Request {

    private String path;
    private String payload;

    public Request(String path, String payload) {
        this.path = path;
        this.payload = payload;
    }

    public Request() {
    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public static class RequestBuilder {

        private String path;
        private Map<String, String> params;
        private String payload;

        public static RequestBuilder newBuilder() {
            return new RequestBuilder();
        }

        public RequestBuilder path(String path) {
            this.path = path;
            return this;
        }

        public RequestBuilder payload(String payload) {
            this.payload = payload;
            return this;
        }

        public Request build() {
            return new Request(path, payload);
        }


    }
}
