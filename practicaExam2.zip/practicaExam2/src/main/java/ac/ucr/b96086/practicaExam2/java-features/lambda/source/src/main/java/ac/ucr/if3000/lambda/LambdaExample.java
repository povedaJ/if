package ac.ucr.b96086.practicaExam2.java;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class LambdaExample {

    public void methodReference() {
        List<Integer> numbers = Arrays.asList(-1, 2, -3, 4, -5, 6, -7, 8, -9);
        numbers.forEach(number -> Math.abs(number));
        numbers.forEach(Math::abs);

        numbers.forEach(n -> print(n));
        numbers.forEach(this::print);
        numbers.forEach(n -> printAsString(n.toString()));

        numbers.stream().sorted(Comparator.naturalOrder());
        numbers.stream().sorted(Comparator.reverseOrder());

        numbers.stream().sorted((a, b) -> a.compareTo(b));
        numbers.stream().sorted((a, b) -> b.compareTo(a));

        List<Person> persons = Arrays.asList(new Person("Ran"), new Person("Bo"));

        persons.stream().sorted(Person::compareTo);
        persons.stream().sorted((a, b) -> a.compareTo(b));

        //No aplica el uso the referencia de método
        persons.stream().sorted((a, b) -> b.compareTo(a));


        List<String> names = Arrays.asList("Bibidi", "Babidi", "Boo");
        names.stream().map(name -> new Person(name));
        names.stream().map(Person::new);
    }

    void print(Integer i) {
        System.out.println(i);
    }

    void printAsString(String i) {
        System.out.println(i);
    }


    static class Person {

        private String name;
        private Integer age;

        Person(String name) {
            this.name = name;
        }

        public int compareTo(Person other) {
            return age.compareTo(other.age);
        }
    }
}
