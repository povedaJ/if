# Interferencia de tipos de variables locales

---

- Introducido en la versión 10 de Java.
- Funciona para declarar una variable local infiriendo su tipo.

---


## ¿Hay un problema?

- Siempre ha sido algo deseado por los programadores el hecho de reutilizar código inclusive en cosas tan sencillas como la declaración de una variable

````
String name = "Icarus";
Integer age = 17;
````

---


- Ya desde el principio ese comportamiento se ve reflejado en algunas de los tipos de datos que provee el lenguaje, una que nació con el lenguaje(String) y otra que fue introducida tiempo después
  (Integer con el autoboxing).
- Por lo que técnicamente siguiendo las reglas que se aplican para los otros objetos originalmente dadas declaraciones serían así:

---


````
String name = new String("Icarus");
Integer age = new Integer(17);
````

- Dado esto se ha buscado la manera de reducir la redundancia de código.
- Es de aquí donde nace la introducción del `var` como palabra para declarar variables donde se dé esta redundancia.

---


````
HashMap<String, String> map=new HashMap<>();
Contact contact=new Contact();
````

Aquí la redundancia está en la indicación doble del tipo de dato `HashMap` y `Contact`, donde tenemos que indicar dos veces el tipo de dato.

---


## Antecedentes con otros lenguajes

- A diferencia de otros lenguajes como JavaScript que infieren el tipo de dato.
    - Claro esta, esto tiene sus consecuencias. Puesto que Javascript no es un lenguaje tipado.
- Pero al final de cuentas un lenguaje con esta característica algunas veces facilita la lectura del código donde se puede inferir el tipo de dato.

- Aquí se tiene una declaración de una variable pero en Javascript.

````Javascript
var word = "Hello"
````

---


## ¿Cómo funciona?

- Funciona similar al ejemplo en Javascript, donde si implícitamente se puede discernir el tipo de dato, este es ignorado de la declaración, reemplazándolo por la palabra `var` de esta forma queda
  casi igual que la sintaxis mostrada anteriormente


---


Esto:

````
String word="Hello";
````

Se puede reemplazar por esto:

````
var word="Hello";
````

---


Esto:

````
List numbers=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
````

Se puede reemplazar por esto:

````
var numbers=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
````

---


Esto:

````
Contact word=new Contact();
````

Se puede reemplazar por esto:

````
var word=new Contact();
````

---


Como nota curiosa, `var` no es una palabra reservada, por lo que se puede seguir utilizando para nombres de variables, métodos y clases

````
var var="var";
var bar=var;
````

---


## Restricciones

- Esta funcionalidad del lenguaje solo se puede utilizar en variables locales, por lo que solo puede ser declaradas en métodos, de esta manera:

````java
class NoAllowed {
    var a = 1;

    public void b(var a) {
    }
}
````

---


Ninguna de las dos declaraciones de la clase son válidas

Tampoco es posible realizar una declaración sin que esté implícito el tipo de variable

````
var a=null;
var b;
````

---


Ambas declaraciones no son válidas, puesto que:

- En la primera el `null` no infiere ningún tipo de variable. Cualquier variable de tipo referencia puede ser `null`.
- En la segunda no se hace la asignación, solo la declaración, lo cual nunca especifica el tipo de dato.

---


Otro ejemplo que no es posible realizar es el siguiente:

````
Function<String, Integer> strToInt=(param)->Integer.parseInt(param)*2;
````

No se puede traducir a esto:

````
var strToInt=(param)->Integer.parseInt(param)*2;
````

---


## Úsese con cuidado

Se recomienda utilizar en situaciones donde el tipo de la variable sea de fácil identificación por parte del programador. Por lo tanto son situaciones donde el uso es legal, pero puede hacer el código
difícil de entender:

````
var response=service.findAll();
````

---


En algunas ocasiones el intuir el tipo de dato de retorno puede no ser tan claro en primera instancia, todo queda delegado al contexto

````
var contacts=contactService.findAll();
````

---


Un simple cambio en el uso de las variables puede hacer la diferencia

Usarlo con Generics es igual de cuidadoso que la declaración acostumbrada, se debe especificar el tipo del Generic en algún lado

````
List<String> list=new ArrayList<>();
````

---


Eventualmente se puede reemplazar por esto

```
var varList=new ArrayList<>();
```

---


Sin embargo se está perdiendo el Generic por lo que se recomienda la mención del mismo en la creación del objeto

```
var varList=new ArrayList<String>();
```

---


## Conclusión

Se recomienda el uso de `var` a discreción si bien es una buena manera de eliminar el código repetitivo, algunas veces el código puede quedar más confuso de lo que ya era.

---



## Referencias
- https://www.baeldung.com/java-10-local-variable-type-inference