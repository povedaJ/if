package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class GasStation {
    private Semaphore semaphore;
    public static void main(String[] args) {
        ExecutorService service = Executors.newCachedThreadPool();
        GasStation gasStation = new GasStation(2);
        service.submit(new Car("1", gasStation));
        service.submit(new Car("2", gasStation));
        service.submit(new Car("3", gasStation));
        service.shutdown();
    }
    public GasStation(int availableSlots) {
        semaphore = new Semaphore(availableSlots);
    }

    public void gettingInLine() {
        try {
            semaphore.acquire();
        } catch (InterruptedException ignored) {
        }
    }

    public void leavingGasStation() {
        semaphore.release();
    }
}



 class Car implements Runnable {
    private final String name;
    private GasStation gasStation;

    public Car(String name, GasStation gasStation) {
        this.gasStation = gasStation;
        this.name = name;
    }

    @Override
    public void run() {
        System.out.printf("Car %s is moving\n", name);
        sleep();
        System.out.printf("%s needs fuel\n", name);
        gasStation.gettingInLine();
        System.out.printf("%s is getting gasoline\n", name);
        sleep();
        System.out.printf("%s is on the road\n", name);
        gasStation.leavingGasStation();
    }

    private void sleep() {
        try {
            Thread.sleep(new Random().nextInt(5000));
        } catch (InterruptedException ignored) {
        }
    }
}