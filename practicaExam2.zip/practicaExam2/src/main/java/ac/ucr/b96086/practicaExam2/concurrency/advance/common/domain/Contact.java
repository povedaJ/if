package ac.ucr.b96086.practicaExam2.concurrency.advance.common.domain;


import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceEntity;

import java.time.LocalDate;

public class Contact implements PersistenceEntity {
    private String name;
    private String surname;
    private LocalDate birthDate;
    private Phone phones[];
    private Address address;

    public Contact() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public Phone[] getPhones() {
        return phones;
    }

    public void setPhones(Phone[] phones) {
        this.phones = phones;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(name)
                .append(" ").append(surname)
                .append(", ").append(birthDate);

        return sb.toString();
    }

    @Override
    public String getId() {
        return new StringBuilder(getName())
                .append('-')
                .append(getSurname())
                .append('-')
                .append(getBirthDate())
                .toString();
    }
}