package ac.ucr.b96086.practicaExam2.concurrency.rentrantReadWrite;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static ac.ucr.if3000.concurrency.OutputUtil.*;

public class ReentrantReadWriteLockDemo {
    public static void main(String[] args) {
        Bar bar = new Bar();
        ExecutorService service = Executors.newCachedThreadPool();
        service.submit(new Client("John", ANSI_BLUE, bar));
        service.submit(new Client("Dave", ANSI_YELLOW, bar));
        service.submit(new Client("Gabe", ANSI_GREEN, bar));
        service.submit(new Client("Robi", ANSI_PURPLE, bar));
        service.submit(new Client("Marg", ANSI_BLACK, bar));
        service.submit(new Client("Till", ANSI_CYAN, bar));
    }
}

class Bar {
    private ReadWriteLock lock = new ReentrantReadWriteLock();
    private Random random = new Random();

    public void getBeer(Client client) {
        try {
            lock.readLock().lock();
            System.out.printf("%sBar: Off course %s\n%s", client.getColor(), client.getName(), ANSI_RESET);
            Thread.sleep(random.nextInt(2000));
        } catch (InterruptedException ignored) {

        } finally {
            System.out.printf("%sBar: %s take your beer\n%s", client.getColor(), client.getName(), ANSI_RESET);
            lock.readLock().unlock();
        }
    }

    public void pay(Client client) {
        try {
            lock.writeLock().lock();
            System.out.printf("%sBar:Sure take your invoice %s\n%s", client.getColor(), client.getName(), ANSI_RESET);
            Thread.sleep(random.nextInt(2000));
        } catch (InterruptedException ignored) {

        } finally {
            System.out.printf("%sBar: %s Thanks see you soon!!\n%s",
                    client.getColor(), client.getName(), ANSI_RESET);
            lock.writeLock().unlock();
        }
    }
}

class Client implements Runnable {
    private final Bar bar;
    private final String name;
    private final Random random = new Random();
    private final String color;

    public Client(String name, String color, Bar bar) {
        this.name = name;
        this.bar = bar;
        this.color = color;
    }

    @Override
    public void run() {
        System.out.printf("%s%s: is in the bar\n%s", color, name, ANSI_RESET);
        while (true) {
            try {
                Thread.sleep(random.nextInt(10000));
                System.out.printf("%s%s: may I have a beer?\n%s", color, name, ANSI_RESET);
                bar.getBeer(this);
                if (random.nextBoolean()) {
                    System.out.printf("%s%s Can you give me the invoice?\n%s", color, name, ANSI_RESET);
                    bar.pay(this);
                }
            } catch (InterruptedException ignored) {
            }
        }
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }
}