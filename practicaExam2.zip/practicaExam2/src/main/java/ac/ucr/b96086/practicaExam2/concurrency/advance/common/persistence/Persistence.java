package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence;

import java.util.List;

public interface Persistence<E extends PersistenceEntity> {

    boolean save(E entity);

    boolean delete(String id);

    List<E> findAll();
}
