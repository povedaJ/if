package ac.ucr.b96086.practicaExam2.java;

public class DefaultMethodExample {
    interface Transport {
        void move(int meters);

        default int estimatedTime(int distance, int velocity) {
            System.out.println("Calculating estimated time");
            return distance / velocity;
        }
    }

    interface FlyingShip {
        default int estimatedTime(int distance, int velocity) {
            System.out.println("Calculating estimated time");
            return distance / velocity;
        }
    }


    static class Airplane implements Transport, FlyingShip {

        @Override
        public void move(int meters) {
            System.out.println("Transporting");
        }

        @Override
        public int estimatedTime(int distance, int velocity) {
            int transport = Transport.super.estimatedTime(distance, velocity);
            int flyingShip = FlyingShip.super.estimatedTime(distance, velocity);
            if (transport < flyingShip) return transport;
            else return flyingShip;

        }
    }
}
