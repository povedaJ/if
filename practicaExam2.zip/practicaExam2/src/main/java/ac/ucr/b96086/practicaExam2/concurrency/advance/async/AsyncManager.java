package ac.ucr.b96086.practicaExam2.concurrency.advance.async;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AsyncManager {

    private static final ExecutorService service = Executors.newCachedThreadPool();

    /**
     * Esto es solo un ejemplo
     * @param process
     */
    @Deprecated
    public static void execute(Runnable process) {

        service.execute(process);
    }

    public static <R> void submit(Async<R> process) {
        service.submit(() -> {
            try {
                process.onSuccess(process.execute());
            } catch (Throwable ex) {
                process.onFail(ex);
            }

        });
    }
}


