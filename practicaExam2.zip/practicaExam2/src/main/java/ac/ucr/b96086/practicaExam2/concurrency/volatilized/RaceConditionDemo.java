package ac.ucr.b96086.practicaExam2.concurrency.volatilized;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RaceConditionDemo {
    public static void main(String[] args) throws InterruptedException {
        executeDemo(new LapChecker());
    }

    public static void executeDemo(LapChecker validator) {
        System.out.println("Principal:" + Thread.currentThread().getName());
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(new Planet(validator));
        service.execute(new Planet(validator));
        service.execute(new Planet(validator));
        service.execute(new Planet(validator));
        service.execute(new Planet(validator));
        while (true) {
            validator.validate(Planet.totalLaps);

            if (Planet.totalLaps >= 50) {
                break;
            }
        }
    }

    static class LapChecker {
        volatile int last = 0;

        public void validate(int number) {
            if (number < last) {
                throw new RuntimeException(Thread.currentThread().getName() + ":Inconsistencia de valores:" + last + " > " + number);
            }
            last = number;
        }
    }

    static class Planet implements Runnable {
        public static volatile int totalLaps = 0;
        private final LapChecker lapChecker;

        public Planet(LapChecker validator) {
            this.lapChecker = validator;
        }

        @Override
        public void run() {
            System.out.println("Planet:" + Thread.currentThread().getName());
            for (int i = 0; i < 10; i++) {
                synchronized (lapChecker) {
                    totalLaps++;
                    lapChecker.validate(totalLaps);
                }

            }
        }

    }


}

