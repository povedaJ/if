# Expresiones Lambda

---

## Conceptos básicos

---

### ¿Qué son expresiones lambda?

- Son expresiones de código que toman como entrada una cantidad de parámetros y retornan un valor.
- Son similares a los métodos, pero no necesitan un nombre y se pueden implementar en el cuerpo de un método
- Fueron añadidas en Java desde la versión 8

---

### ¿Por qué las llamamos expresiones lambda?

- Tiene su raíz en el Cálculo.
- En matemática, un cálculo lambda es un donde en donde una serie de valores es mapeado a un cálculo

````
f(x) = 2x
f(x, y) = 2x + y
f(x, y, z) = (2x + y) * z
````

---

- La idea es tener una lista de variables y generar un resultado con una sola expresión.
- En el corolario computacional la idea de tener una sola expresión se desmorona cuando se le agregan múltiples expresiones (sentencias) a una expresión.
-

---

### Sintaxis

```
 param->expression // Un solo parámetro, una sola sentencia
 (param1,param2)->expression // Dos o más parámetros, una sola sentencia
```

---

#### Donde:

- `param`, `param1`, `param2`: Parámetros que respetan el tipo del método que se requiere ejecutar.
- `expresssion`: Debe respetar el tipo de retorno del método que se va a ejecutar.
- `sentence1`, `sentence2`: Sentencias a ejecutar, si el método que se invoca retorna un valor la última sentencia debe ser una de retorno.

---

### Aplicando expresiones Lambda

````
f = (x) -> x * 2;
g = (x,y) -> x + y;
````

#### Nota sobre las expresiones

> Estas son limitadas: No se pueden declarar variables e inmediatamente deben retornar un valor o asignar estructuras de control

- Para solventar esta limitante se utilizan bloques de código donde se pueden declarar múltiples líneas

````
 (param1,param2)->{sentence1;sentence2;} // Dos o más parámetros, una sola sentencia
````

---

- Si la expresión lambda debe retornar un valor la última línea debe ser una sentencia `return`

````
 (param1,param2)->{
      sentence1;
      sentence2;
      return value;
    } // Dos o más parámetros, una sola sentencia
````

---

### Ejemplos

```
list.sort((value1,value2)->value1.compareTo(value1));
```

---

````java

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> theNumbers = new ArrayList<>();
        theNumbers.add(1);
        theNumbers.add(2);
        theNumbers.add(3);
        theNumbers.forEach((n) -> System.out.println(n));
        int max = theNumbers.stream().max((a, b) -> a > b);
        int minCustom = theNumbers.stream().min((a, b) -> {
            int a1 = a * 71;
            int b1 = b * 71;
            return b > a;
        });
    }
}
````

---

## Detrás de una expresión Lambda

---

### Clases anónimas

- Es una clase que no tiene nombre y para la que solo se crea una instancia.

---

### Ejemplo de una clase anónima

- Por ejemplo antes de la versión Java 8 para agregar un evento a un componente `JButton` del paquete swing necesitábamos crear una clase anónima cuyo código será único para esa acción.
- Puesto que el único requisito para crear la instancia es que la clase que se cree implemente la interfaz ActionListener.

---

````java
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class FormFx {
    JButton button = new JButton();

    void addEvent() {
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button pressed");
            }
        });
    }
}
````

---


El ejemplo anterior es equivalente a esto

````java
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class FormFx {
    JButton button = new JButton();

    void addEvent() {
        ButtonEvent event = new ButtonEvent();
        button.addActionListener(event);
    }
}

class ButtonEvent implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Button pressed");
    }
}
````

---

- Donde no estamos creando la clase anónima en su lugar creamos una clase específica, sin embargo puesto que la única función de dicha clase será para ejecutar la acción lo resumimos como el primer
  ejemplo.
- En cualquiera de los dos casos eventualmente el método `actionPerformed` de nuestra clase será ejecutado cuando se presione el botón, dicha implementación queda a discreción de en este caso el
  botón. Esto se da gracias a que estamos aplicando:
    - El principio de herencia: Esto al crear una especialización de la interfaz.
    - Responsabilidad única: Puesto que la única responsabilidad que tendrá nuestra clase será ejecutar la acción del botón.

---

### De clases anónimas a Expresiones Lambda

- En el caso anterior el método `addActionListener` recibe como parámetro una instancia de `ActionListener` que es una interfaz que solo contiene un método.
- El hecho que esta interfaz solo tenga un método tiene un trasfondo importante como prerrequisito para la creación de expresiones lambda.
- Si analizamos la sintaxis de la expresión lambda estas se centran en la implementación de una única expresión que se pasa como parámetro
- Dicha expresión internamente es el cuerpo de un método que puede recibir parámetros o no así como puede retornar un valor o no.
- Esto es el requisito esencial que se necesita para implementar una expresión lambda: Una interfaz que tenga un solo método que pueda:
    - Recibir parámetros y retornar un valor: `(param)-> {return value;}`
    - No recibir parámetros y retornar un valor: `()-> {return value;}`
    - Recibir parámetros y no retornar un valor. `(param)-> {expression}`

---

### Crear una interfaz para ser utilizada para una expresión lambda

````java
import java.math.BigDecimal;

@FunctionalInterface
interface Transaction {
    BigDecimal apply(BigDecimal accountAmount);
}

class Account {
    BigDecimal amount;

    void transaction(Transaction transaction) {
        transaction.apply(amount);
    }
}

````

---



En el código anterior se define una interfaz llamada `Transaction` intencionalmente se utiliza la anotación `FunctionalInterface` para dar a saber que dicha interfaz será utilizada como una función

Para emplear dicha instrucción se hace de la siguiente manera

````java
import java.math.BigDecimal;

class DebitTransaction {

    void debitAmount(Account account, BigDecimal debit) {
        account.transaction((amount) -> amount.substract(debit));
    }
}
````

---

#### Funciones predefinidas

- En el ejemplo anterior nos deja claro como implementar una función lambda a partir de una interfaz con un solo método lo que deriva en la siguiente pregunta:

> ¿Debo crear una interfaz para cada método que se necesita facilitar la implementación de instrucciones lambda?

---


La respuesta técnica a esta pregunta sería un rotundo sí. Pero podemos analizar el objetivo de cada función y podemos reducir la cantidad de interfaces-funciones que se pueden crear:

- Si observamos bien la interfaz `Transaction` definida en este ejemplo, esta no tiene ninguna implicación como tal en la implementación de la funcionalidad de transacción.
- Esto quiere decir que en el método `transaction` de la clase `Account` se podría reemplazar el parámetro de entrada por otro que respete las mismas condiciones: En este caso, la de recibir un
  parámetro y retornar un valor, en ambos casos de tipo `BigDecimal`.

---

- Sin embargo pensando en que funciones con estas características son frecuentes de implementar por lo que como parte del API de Java con la inclusión de expresiones lambda también se incluye un
  paquete de funciones que pueden perfectamente substituir cualquier potencial interfaz-función que se necesite crear que sea tan básica como la del ejemplo.

---


En el paquete `java.util.function` existe una serie de funciones utilitarias que pueden servir para ser utilizadas en diferentes circunstancias. Recordando lo mencionado anteriormente, podemos enlazar
algunas de estas funciones con los siguientes escenarios

- Recibir parámetros y retornar un valor: `(param)-> {return value;}` -> `Function<T,R>`. Donde T es el parámetro del método y R el valor de retorno
- No recibir parámetros y retornar un valor: `()-> {return value;}` -> `Supplier<T>`. Donde T es el valor de retorno.
- Recibir parámetros y no retornar un valor. `(param)-> {expression}` -> `Consumer<T>`. Donde T es el parámetro del método.

---


De esta forma podemos redefinir nuestra clase `Account` de la siguiente manera

````java
import java.math.BigDecimal;
import java.util.function.Function;

class Account {
    BigDecimal amount;

    void transaction(Function<BigDecimal, BigDecimal> transaction) {
        transaction.accept(amount);
    }
}

````

---


El código que consume dicha clase no va a cambiar en absoluto, puesto que la interfaz `Function` cumple con las mismas condiciones que su antecesora y aprovechándose de los Generics el tipo del
parámetro puede variar según la especialización.

`account.transaction((amount) -> amount.substract(debit));`

---

#### Ejemplos de implementaciones de funciones predefinidas

##### forEach

- Cada lista tiene un método que sirve para iterar sobre la lista si vemos la definición de este método teneos que:

````java
@Override
public void forEach(Consumer<? super E>action){
        /../
        action.accept(elementAt(es,i));
        /../
        }
````

---

- Donde se recibe un objeto de tipo `Consumer` que recibe un parámetro pero no retorna valor.
- En este contexto el Consumer va a manipular un objeto de tipo `E` que es el tipo que maneja la lista.
- A su vez puede ser cualquier padre del tipo de la lista.

---

##### map

- La interfaz `Stream` utilizada para hacer streaming a una colección posee un método para realizar un mapeo de cada nodo a otro tipo por lo tanto se define de la siguiente manera

````java

<R> Stream<R> map(Function<? super T,?extends R>mapper);
````

---

- Este método recibe una objeto de tipo `Function` lo que quiere decir que recibe un objeto de tipo `T` y retorna uno de tipo `R`, donde `T` es el tipo que manipula el `Stream` y R es el tipo
  resultante del mapeo.

---

##### generate

- Este es un método estático de la interfaz `Stream` utilizado para generar una lista infinita de valores desordenados

````java
public static<T> Stream<T> generate(Supplier<?extends T> s){
        Objects.requireNonNull(s);
        return StreamSupport.stream(
        new StreamSpliterators.InfiniteSupplyingSpliterator.OfRef<>(Long.MAX_VALUE,s),false);
        }
````

- Para este caso `Supplier` es utilizado, puesto que se necesita una función que genere un valor de tipo `T` y en este caso no tenemos ninguna entrada.

---

## Referencias

- [W3Schools](https://www.w3schools.com/java/java_lambda.asp#:~:text=Lambda%20Expressions%20were%20added%20in,the%20body%20of%20a%20method.): Explicación básica de lo que significa una expresión
  lambda con ejemplos en Java.
- [OpenWebinars](https://openwebinars.net/blog/crear-expresiones-lambda-en-java/): Otra explicación básica de expresiones lambda, esta vez aplicándolas con Java Streams.
- https://www.baeldung.com/java-8-lambda-expressions-tips
- https://www.theserverside.com/blog/Coffee-Talk-Java-News-Stories-and-Opinions/What-is-a-lambda-function-and-from-where-did-the-term-lambda-elute
