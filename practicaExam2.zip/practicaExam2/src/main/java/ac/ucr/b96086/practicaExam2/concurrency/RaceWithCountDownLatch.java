package ac.ucr.b96086.practicaExam2.concurrency;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RaceWithCountDownLatch {
    private RacerWithCountDownLatch racer1;
    private RacerWithCountDownLatch racer2;
    private RacerWithCountDownLatch racer3;
    private CountDownLatch countDownLatch = new CountDownLatch(3);

    public static void main(String args[]) {
        RaceWithCountDownLatch race = new RaceWithCountDownLatch();
        race.prepareRacer();
        race.startRace();
    }

    public void prepareRacer() {
        countDownLatch = new CountDownLatch(3);
        racer1 = new RacerWithCountDownLatch("La Pulga", countDownLatch);
        racer2 = new RacerWithCountDownLatch("El Fenómeno", countDownLatch);
        racer3 = new RacerWithCountDownLatch("El Bicho", countDownLatch);
    }

    public void startRace() {
        ExecutorService threadExecutor =
                Executors.newFixedThreadPool(10);
        threadExecutor.execute(racer1);
        threadExecutor.execute(racer2);
        threadExecutor.execute(racer3);
        threadExecutor.shutdown();
       // try {
            //countDownLatch.await();
            System.out.println("Todos los corredores terminaron la tarea");
      //  } catch (InterruptedException e) {/*TODO manejar exception*/}
    }
}

class RacerWithCountDownLatch implements Runnable {
    private String name;
    private CountDownLatch countDownLatch;

    public RacerWithCountDownLatch(String name, CountDownLatch countDownLatch) {
        this.name = name;
        this.countDownLatch = countDownLatch;
    }

    @Override
    public void run() {
        countDownLatch.countDown();
        try {
            countDownLatch.await();
            System.out.printf("%s starts to run\n", name);
            Thread.sleep(new Random().nextInt(10000));
        } catch (InterruptedException e) {/*TODO imprimir exception*/}
        System.out.println(String.format("%s ends to run", name));
    }
}