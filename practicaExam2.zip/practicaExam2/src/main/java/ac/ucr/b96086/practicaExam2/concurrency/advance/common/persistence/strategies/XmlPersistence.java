package ac.ucr.b96086.practicaExam2.concurrency.advance.common.persistence.strategies;


import ac.ucr.if3000.concurrency.advance.common.persistence.Persistence;
import ac.ucr.if3000.concurrency.advance.common.persistence.PersistenceEntity;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Serializa y deserializa XML
 * https://www.baeldung.com/jackson-xml-serialization-and-deserialization
 */
public class XmlPersistence<E extends PersistenceEntity> extends FilePersistence<E> implements Persistence<E> {

    public XmlPersistence(Class<E> clazz, String root) {
        super(root, clazz, "xml");
    }

    @Override
    public boolean save(E entity) {
        try {
            storeFile(entity);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    @Override
    public boolean delete(String id) {
        return deleteFile(id);
    }

    @Override
    public List<E> findAll() {
        return this.findAllFiles(fileType).stream()
                .map(entity -> readValue(entity, super.clazz))
                .collect(Collectors.toList());
    }

    @Override
    protected String convert(PersistenceEntity entity) {
        try {
            return mapper().writeValueAsString(entity);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    private E readValue(String entity, Class<E> clazz) {
        try {
            return mapper().readValue(entity, clazz);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private XmlMapper mapper() {
        XmlMapper mapper = new XmlMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return mapper;

    }
}